
0.0.6 / 2013-09-06 
==================

 * only prevent default if we have two fingers down

0.0.5 / 2013-09-04 
==================

 * added pinching to only call touchmove and touchend when pinching

0.0.4 / 2013-09-03 
==================

 * simplified & fixed occasional 'stuck' state

0.0.3 / 2013-09-02 
==================

 * make event object mutable

0.0.2 / 2013-09-02 
==================

 * save last scale instead of resetting each time

0.0.1 / 2013-08-30 
==================

 * Initial commit
